package org.avol.sample;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;

/**
 * Created by Durga on 7/13/2016.
 */

public class CommonCollectionsUsageTest {

    private CommonCollectionsUsage commonCollectionsUsage = new CommonCollectionsUsage();
    @Test
    public void testIsEmpty() {
        List<String> list = new ArrayList<String>() {
            {
                add("Hello");
            }
        };
        assertFalse(commonCollectionsUsage.isEmpty(list));

        assertTrue(commonCollectionsUsage.isNotEmpty(list));
    }
}
