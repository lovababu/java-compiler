package org.avol.sample;

import org.apache.commons.collections.CollectionUtils;

import java.util.Collection;
import java.util.Collections;

/**
 * Created by Durga on 7/13/2016.
 */
public class CommonCollectionsUsage {

    public boolean isEmpty(Collection collection) {
        return CollectionUtils.isEmpty(collection);
    }

    public boolean isNotEmpty(Collection collection) {
        return CollectionUtils.isNotEmpty(collection);
    }
}
